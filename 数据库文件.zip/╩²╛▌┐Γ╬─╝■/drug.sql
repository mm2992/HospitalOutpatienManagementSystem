drop table if exists drug;

/*==============================================================*/
/* Table: drug                                                  */
/*==============================================================*/
create table drug
(
   drug_id              varchar(255) not null,
   drug_name            varchar(255),
   drug_price           double,
   drug_stock           int,
   drug_category        varchar(255),
   product_time         varchar(255),
   expiry_date          varchar(255),
   in_date              varchar(255),
   operator_by          varchar(255),
   manu_id              varchar(255),
   drug_attr            varchar(255),
   primary key (drug_id)
);
