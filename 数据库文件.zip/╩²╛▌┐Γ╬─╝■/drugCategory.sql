drop table if exists drugcategory;

/*==============================================================*/
/* Table: drugcategory                                          */
/*==============================================================*/
create table drugcategory
(
   category_id          varchar(255) not null,
   category_name        varchar(255) not null,
   create_time          varchar(255) not null,
   create_by            varchar(255) not null,
   primary key (category_id)
);
