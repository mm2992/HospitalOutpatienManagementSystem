drop table if exists level;

/*==============================================================*/
/* Table: level                                                 */
/*==============================================================*/
create table level
(
   level_id             varchar(255) not null,
   level_name           varchar(255),
   primary key (level_id)
);
