drop table if exists outRecords;

/*==============================================================*/
/* Table: outRecords                                            */
/*==============================================================*/
create table outRecords
(
   record_id            int not null,
   drug_id              varchar(255),
   drug_name            varchar(255),
   quantity             int,
   mane_id              varchar(255),
   reason               varchar(255),
   operate_by           varchar(255),
   out_time             varchar(255),
   remark               varchar(255),
   primary key (record_id)
);
