drop table if exists department;

/*==============================================================*/
/* Table: department                                            */
/*==============================================================*/
create table department
(
   dept_id              varchar(255) not null,
   dept_name            varchar(255) not null,
   dept_leader          varchar(255) not null,
   primary key (dept_id)
);
