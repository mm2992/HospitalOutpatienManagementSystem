drop table if exists doctor;

/*==============================================================*/
/* Table: doctor                                                */
/*==============================================================*/
create table doctor
(
   doctor_id            varchar(255) not null,
   doctor_name          varchar(255) not null,
   doctor_sex           char(2) not null,
   dept_id              varchar(255) not null,
   level_id             varchar(255) not null,
   entry_date           varchar(255) not null,
   password             varchar(255),
   primary key (doctor_id)
);
