drop table if exists user;

/*==============================================================*/
/* Table: user                                                  */
/*==============================================================*/
create table user
(
   user_id              varchar(255) not null,
   user_name            varchar(255) not null,
   user_sex             char(2) not null,
   user_category        int  not null,
   user_tel             varchar(255) not null,
   entry_time           varchar(255) not null,
   password             varchar(255),
   primary key (user_id)
);
