drop table if exists orderdetail;

/*==============================================================*/
/* Table: orderdetail                                           */
/*==============================================================*/
create table orderdetail
(
   order_id             varchar(255) not null,
   drug_name            varchar(255),
   quantity             int,
   mane_id              varchar(255),
   order_time           varchar(255),
   order_by             varchar(255),
   order_status         int,
   primary key (order_id)
);
