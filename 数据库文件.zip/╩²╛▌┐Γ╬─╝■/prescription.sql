drop table if exists prescription;

/*==============================================================*/
/* Table: prescription                                          */
/*==============================================================*/
create table prescription
(
   patient_id           varchar(255) not null,
   drug_id              varchar(255) not null,
   drug_name            varchar(255),
   quantity             int,
   drug_price           double,
   total_price          double,
   status               int,
   doctor_name          varchar(255),
   doctor_order         varchar(255),
   out_status           int,
   primary key (patient_id, drug_id)
);
