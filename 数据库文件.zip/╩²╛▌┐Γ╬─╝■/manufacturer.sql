drop table if exists manufacturer;

/*==============================================================*/
/* Table: manufacturer                                          */
/*==============================================================*/
create table manufacturer
(
   mane_id              varchar(255) not null,
   mane_name            varchar(255),
   maue_address         varchar(255),
   mane_tel             varchar(255),
   mane_email           varchar(255),
   primary key (mane_id)
);
