drop table if exists patient;

/*==============================================================*/
/* Table: patient                                               */
/*==============================================================*/
create table patient
(
   id_card              varchar(255) not null,
   patient_name         varchar(255),
   patient_sex          char(2),
   dept_id              varchar(255),
   balance              double,
   register_time        varchar(255),
   patient_no           int,
   status               int,
   primary key (id_card)
);
