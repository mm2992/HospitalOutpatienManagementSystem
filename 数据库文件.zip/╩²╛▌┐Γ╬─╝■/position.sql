drop table if exists position;

/*==============================================================*/
/* Table: position                                              */
/*==============================================================*/
create table position
(
   user_category        int not null,
   user_position        varchar(255),
   primary key (user_category)
);
