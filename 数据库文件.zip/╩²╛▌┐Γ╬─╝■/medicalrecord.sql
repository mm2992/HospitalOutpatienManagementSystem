drop table if exists medicalrecord;

/*==============================================================*/
/* Table: medicalrecord                                         */
/*==============================================================*/
create table medicalrecord
(
   patient_id           varchar(255) not null,
   patient_name         varchar(255),
   patient_sex          varchar(255),
   dept_id              varchar(255),
   description          varchar(255),
   see_time             varchar(255),
   doctor_name          varchar(255),
   primary key (patient_id)
);
